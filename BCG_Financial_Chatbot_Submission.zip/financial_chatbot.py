from pathlib import Path
import pandas as pd

DATA_FILE = Path(__file__).with_name("financial_data.csv")
METRICS = {
    "operating cash flow": "Operating Cash Flow (USD millions)",
    "cash flow": "Operating Cash Flow (USD millions)",
    "revenue": "Total Revenue (USD millions)",
    "net income": "Net Income (USD millions)",
    "profit": "Net Income (USD millions)",
    "assets": "Total Assets (USD millions)",
    "liabilities": "Total Liabilities (USD millions)",
}

def load_data():
    return pd.read_csv(DATA_FILE)

def money(value):
    return f"${value:,.0f} million"

def simple_chatbot(user_query, data, last_company=None):
    query = user_query.lower().strip()
    companies = {"microsoft": "Microsoft", "apple": "Apple", "tesla": "Tesla"}
    company = next((v for k, v in companies.items() if k in query), last_company)
    year = next((y for y in (2023, 2024, 2025) if str(y) in query), 2025)

    if query in {"help", "what can you do", "what can you do?"}:
        return ("Ask about revenue, net income/profit, assets, liabilities, or operating cash flow for Microsoft, Apple, or Tesla in 2023–2025. Example: 'Apple revenue 2025'.", company)

    if "highest revenue" in query or ("which company" in query and "revenue" in query):
        subset = data[data["Fiscal Year"] == year]
        row = subset.loc[subset["Total Revenue (USD millions)"].idxmax()]
        return (f"In {year}, {row['Company']} had the highest revenue at {money(row['Total Revenue (USD millions)'])}.", company)

    metric_key = next((k for k in sorted(METRICS, key=len, reverse=True) if k in query), None)
    if company and metric_key:
        if any(w in query for w in ["change", "changed", "growth", "increased", "decreased", "compared"]):
            col = METRICS["revenue"] if "revenue" in query else METRICS["net income"]
            if year == 2023:
                return ("For year-over-year change, ask about 2024 or 2025 so a previous year is available.", company)
            old_row = data[(data.Company == company) & (data["Fiscal Year"] == year - 1)]
            new_row = data[(data.Company == company) & (data["Fiscal Year"] == year)]
            if old_row.empty or new_row.empty:
                return ("I couldn't find that company and year. Try 2023, 2024, or 2025.", company)
            old, new = float(old_row.iloc[0][col]), float(new_row.iloc[0][col])
            delta, pct = new-old, ((new-old)/old*100 if old else 0)
            label = "revenue" if col == METRICS["revenue"] else "net income"
            direction = "increased" if delta > 0 else "decreased" if delta < 0 else "did not change"
            return (f"{company}'s {label} {direction} from {year-1} to {year} by {money(abs(delta))} ({abs(pct):.1f}%).", company)
        col = METRICS[metric_key]
        found = data[(data.Company == company) & (data["Fiscal Year"] == year)]
        if found.empty:
            return ("I couldn't find that company and year. Try 2023, 2024, or 2025.", company)
        label = col.replace(" (USD millions)", "").lower()
        return (f"{company}'s {label} in {year} was {money(found.iloc[0][col])}.", company)

    return ("Sorry, I didn't understand that question. Try 'Apple revenue 2025', 'Tesla net income 2024', 'Microsoft operating cash flow 2025', or 'How did Apple's revenue change in 2025?'. Type 'help' for examples.", company)

def main():
    data = load_data()
    print("BCG Financial Chatbot Prototype")
    print("Ask about Microsoft, Apple, or Tesla for 2023–2025. Type 'help' or 'exit'.")
    context = None
    while True:
        query = input("\nYou: ")
        if query.strip().lower() in {"exit", "quit"}:
            print("Bot: Goodbye!")
            break
        answer, context = simple_chatbot(query, data, context)
        print("Bot:", answer)

if __name__ == "__main__":
    main()
