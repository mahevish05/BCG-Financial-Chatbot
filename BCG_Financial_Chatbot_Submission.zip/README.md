# BCG Financial Chatbot Prototype

## Purpose
A simple rule-based chatbot prototype for the BCG Forage Task 2. It answers predefined questions using the Task 1 financial dataset for Microsoft, Apple, and Tesla from fiscal years 2023–2025.

## Files
- `financial_chatbot.py`: chatbot logic and command-line interaction.
- `financial_data.csv`: financial data used by the chatbot.
- `test_results.txt`: example test results.
- `requirements.txt`: required Python library.

## Run it
1. Install Python 3.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`.
4. Run `python financial_chatbot.py`.
5. Type a question. Type `help` for examples or `exit` to stop.

## Supported examples
- Apple revenue 2025
- What was Tesla's net income in 2024?
- Microsoft operating cash flow 2025
- How did Apple's revenue change in 2025?
- Which company had the highest revenue in 2025?

## How it works
The chatbot uses keyword matching and rule-based logic to identify a company, metric, and year. It retrieves the matching row from the CSV with pandas and returns a plain-language answer. It remembers the last company mentioned for some follow-up questions. Unrecognized queries receive guidance on supported questions.

## Limitations
This is a rule-based prototype, not a generative AI model. It only covers three companies and 2023–2025, does not fetch real-time data, and may not understand every phrasing. Verify figures against the original SEC filings before relying on them. This is a learning prototype, not investment advice.
